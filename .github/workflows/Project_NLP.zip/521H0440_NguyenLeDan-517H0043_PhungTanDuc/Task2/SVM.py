import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.feature_extraction.text import TfidfVectorizer

data = pd.read_csv('facebook_comment_2k7.csv', encoding="ISO-8859-1", lineterminator='\n', on_bad_lines='skip')
data['text'] = data['text'].astype(str)
data['label'] = data['label'].astype(str)

data['label'] = data['label'].apply(lambda x: x.strip('[]').split(', '))
data['label'] = data['label'].apply(lambda x: [i.replace("'", "").replace("]", "").replace('"', '').strip() for i in x])
data = data[data['label'].apply(lambda x: 'nan' not in x)]

mlb = MultiLabelBinarizer()
data_labels = mlb.fit_transform(data['label'])

data_labels_single = np.argmax(data_labels, axis=1)

vectorizer = TfidfVectorizer()
X_vectors = vectorizer.fit_transform(data['text'])

classifier = SVC(probability=True)
classifier.fit(X_vectors, data_labels_single)

test_data = pd.read_csv('test_data.csv')
test_data['text'] = test_data['text'].astype(str)

test_vectors = vectorizer.transform(test_data['text'])

probability = classifier.predict_proba(test_vectors)
predict_label = None
min_probability = 0

for i in range(len(test_data)):
    print("Text:", test_data['text'].iloc[i])
    for label, prob in zip(mlb.classes_, probability[i]):
        print("Probability for {}: {:.4f}".format(label, prob))
        if prob > min_probability:
            min_probability = prob
            predict_label = label
    
    print("Label prediction:", predict_label , "\n")
    min_probability = 0
