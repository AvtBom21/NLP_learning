import pandas as pd
import fasttext
from sklearn.model_selection import train_test_split

data = pd.read_csv('facebook_comment_2k7.csv', encoding="ISO-8859-1", lineterminator='\n', on_bad_lines='skip')

data['text'] = data['text'].astype(str)
data['label'] = data['label'].astype(str)
data['label'] = data['label'].apply(lambda x: x.strip('[]').split(', '))
data['label'] = data['label'].apply(lambda x: [i.replace("'", "").replace("]", "").replace('"', '').strip() for i in x])
data = data[data['label'].apply(lambda x: 'nan' not in x)]

train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)

train_data['labels'] = train_data['label'].apply(lambda x: '__label__' + ' __label__'.join(x))
train_data['text'] = train_data['text'].apply(lambda x: x.replace('\n', ' '))

test_data['text'] = test_data['text'].apply(lambda x: x.replace('\n', ' '))

train_fasttext_format = train_data[['labels', 'text']].apply(lambda x: ' '.join(x), axis=1)
train_fasttext_format.to_csv('train.txt', index=False, header=False, sep='\t')

model = fasttext.train_supervised(input='train.txt', epoch=25)

model.save_model("model.bin")

test_data = pd.read_csv('test_data.csv')
test_data['text'] = test_data['text'].astype(str)

test_data['text'] = test_data['text'].apply(lambda x: x.replace('\n', ' '))

model = fasttext.load_model('model.bin')

predictions = []
probabilities = []
for text in test_data['text']:
    pred, prob = model.predict(text)
    predictions.append(pred[0])
    probabilities.append(prob[0])

test_data['predictions'] = predictions
test_data['probabilities'] = probabilities

print(test_data[['text', 'predictions', 'probabilities']])