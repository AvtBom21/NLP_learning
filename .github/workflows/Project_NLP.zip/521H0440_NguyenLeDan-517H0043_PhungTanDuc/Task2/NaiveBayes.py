import pandas as pd
import numpy as np
from sklearn.naive_bayes import MultinomialNB
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

data = pd.read_csv('facebook_comment_2k7.csv', encoding="ISO-8859-1", lineterminator='\n', on_bad_lines='skip')
data['text'] = data['text'].astype(str)
data['label'] = data['label'].astype(str)

data['label'] = data['label'].apply(lambda x: x.strip('[]').split(', '))
data['label'] = data['label'].apply(lambda x: [i.replace("'", "").replace("]", "").replace('"', '').strip() for i in x])
data = data[data['label'].apply(lambda x: 'nan' not in x)]

mlb = MultiLabelBinarizer()
data_labels = mlb.fit_transform(data['label'])

X_train, X_test, y_train, y_test = train_test_split(data['text'], data_labels, test_size=0.2, random_state=42)

vectorizer = TfidfVectorizer()
X_train_vectors = vectorizer.fit_transform(X_train)
X_test_vectors = vectorizer.transform(X_test)

classifier = MultinomialNB(alpha=0.1)
classifier.fit(X_train_vectors, np.argmax(y_train, axis=1))

y_pred = classifier.predict(X_test_vectors)

test_data = pd.read_csv('test_data.csv')
test_data['text'] = test_data['text'].astype(str)

test_vectors = vectorizer.transform(test_data['text'])

probability = classifier.predict_proba(test_vectors)
predict_label = None
min_probability = 0

for i in range(len(test_data)):
    print("Text:", test_data['text'].iloc[i])
    for label, prob in zip(mlb.classes_, probability[i]):
        print("Probability for {}: {:.4f}".format(label, prob))
        if prob > min_probability:
            min_probability = prob
            predict_label = label
    
    print("Label prediction:", predict_label , "\n")
    min_probability = 0
